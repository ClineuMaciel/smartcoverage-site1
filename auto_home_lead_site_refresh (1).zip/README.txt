SmartCoverage Lead Gen Site

This is a placeholder rebuild of the website package.